﻿//tento testovaci server v OS Windows10  komunikuje  pres LAN s klientem OS mbed

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace TCPser
{
    internal class Program
    {

        static  FileStream fs;
        static string path = @"C:\Users\marek\source\repos\TCPser\franta.txt";//muj zkusebni soubor, jinak muze byt libovolny
        static int port = 8080;         //zkusebni port,muze byt libovolny
        static void Main(string[] args)
        {
            bool esc=false;
            byte[] buffer = new byte[0x400];//buffer pro prijata data
            if (!File.Exists(path))
                fs = File.Create(path) ;    //pripadne vytvori  novy soubor
            TcpListener listener = new TcpListener(IPAddress.Any, port);// vytvori serverovy socket
            listener.Start();
            int i = 0;
            Console.WriteLine("Exit this program with ESC key");
            do
            {
                Console.Write("Waiting for a connection...");
                Console.WriteLine(i);
                try
                {
                    TcpClient client = listener.AcceptTcpClient();//pripoji klienta 
                    NetworkStream stream = client.GetStream();//vytvori datovy proud
                    while (!stream.DataAvailable && (esc == false)) {//ceka na data od klienta nebo na prikaz ukonceni programu
                        if (Console.KeyAvailable == true)//to je jen pridan pokus o ukonceni programu klavesou ESC
                        {
                            ConsoleKey ke = Console.ReadKey(true).Key;
                             esc = (ke == ConsoleKey.Escape);
                        }
                        Thread.Sleep(100); //prip. se provadeni cyklu treba na 100ms uspi 
                    };
                    if (esc == false)//pokud neukoncuji program
                    {
                        fs = File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None);//otevre soubor pro zapis prijatych dat
                        Console.WriteLine("DataAvailable");
                        int l = 0, k = 0;
                        do
                        {
                            k = stream.Read(buffer, 0, 0x400);//prijima po 1kB data od klienta,
                            l += k;                           //  pocita byty
                            fs.Write(buffer, 0, k);           //a zapisuje do otevreneho souboru  
                        }
                        while (k > 0);      //dokud se klient sam neodpoji(nebo by mohl zustat trvale pripojen, server by cetl ze streamu  po Bytech dokud by neprijal znak EOF)
                        fs.Close();         //uzavre soubor s prectenymi daty
                        stream.Close();     // zde i server spojeni ukonci
                        client.Close();   
                        client = listener.AcceptTcpClient();// a znovu vzapeti znovu spojeni navaze
                        stream = client.GetStream();
                        string str = "prijato: " + l.ToString() + "\n";
                        stream.Write(Encoding.ASCII.GetBytes(str), 0, str.Length );// aby mohl klientovy poslat pro kontrolu treba aspon pocet prijatych dat
                        stream.Close();
                        client.Close();
                        i++;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error: " + e.Message);
                }
            }
            while (esc== false);
            listener.Stop();
            fs.Close();
        }

    }
}

