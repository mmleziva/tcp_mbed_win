 
#include "marek.h"
#define PAKL 1024
int n,sf,k;
BlockDevice* root;
  int m;
FATFileSystem ota_data_fs("fs");
 FILE* fp;
const char *buf;
char sbuffer[256],rbuffer[16];
 TCPSocket socket;
 SocketAddress a;
   // Network interface
EthernetInterface net;
 nsapi_error_t err,erropen;
 int h,j=0;
void setmar(void)
{
   // root = BlockDevice::get_default_instance();
  //  int m=ota_data_fs.mount(root); 	
    // Serial.print(m);

    net.connect();
   
    // Show the network address
 
    net.get_ip_address(&a);
    buf = a.get_ip_address();
    Serial.print("IPclient:");
    Serial.println(buf);
 // Open a socket on the network interface, and create a TCP connection
    nsapi_error_t errgeth= net.gethostbyname("192.168.0.106", &a);
    Serial.print("errgeth:");
    Serial.println((int)errgeth);
    buf = a.get_ip_address();
    Serial.print("IPserver:");
    Serial.println(buf);
    a.set_port(8080);   
    
}

void finmar(void)
{

   {
     
        erropen=socket.open(&net);//t
        Serial.print("erropen:");
        Serial.println((int)erropen);
        err= socket.connect(a);
        Serial.print("errno:");
        Serial.println((int)err);
	     // Serial.print("\n open\n");
        sf=0;
        k=0;
        for (int i = 1; i<=599; i++)
        {
         // h= sprintf(sbuffer,"%d   %d   %d   %d   %d   \n", p_Amain[i],p_Cefe[i],p_Fsuma[i],p_Esuma[i], p_DsumM[i]);//test
           h= sprintf(sbuffer,"%d   %d   %d   %d   %d   \n",j,j,j,j,j);//test
           sf += h;
           j++;
           int scount = socket.send(sbuffer,h);       
        } 
        socket.close();
        delay(100); 
        erropen=socket.open(&net);
        Serial.print("erroprec:");
        Serial.println((int)erropen);
        err=socket.connect(a);
        Serial.print("errec:");
        Serial.println((int)err);
        int rcount = socket.recv(rbuffer, sizeof rbuffer);
        socket.close();
        Serial.print("rbuffer received:");
        Serial.println(rbuffer);
        Serial.println();
        //net.disconnect();
   }
}
