#include "marek.h"
#include "Arduino.h"


int p_Fmain[610];
int p_Amain[610];
int p_Fsuma[610];
int p_Esuma[610];
int p_DsumM[610];
int p_Cefe[610];

//
void setup()
{

 
  Serial.begin(9600);
  // Initialize OPTA LEDs
	pinMode(LED_D0, OUTPUT);
	pinMode(LED_D1, OUTPUT);
	pinMode(LED_D2, OUTPUT);
	pinMode(LED_D3, OUTPUT);
	pinMode(BTN_USER, INPUT);
  //
  analogReadResolution(16);
  setmar();
  finmar();//t
}
// The loop function runs over and over again while the device is on
void loop()
{  
    // zacatek mereni LED_1  
    digitalWrite(LED_D0, HIGH);
    delay(1000);
    // 
    digitalWrite(LED_D0, LOW);
    // vyhodnoceni
      digitalWrite(LED_D1, HIGH);
      delay (15000); // kdyz neni signal ceka 15 sekund na dalsi mereni, ulozi 0
    //
    // ulozi hodnoty za uplynulou sekundu 
    
    // odesle hodnoty za uplynulych 10 minut do souboru 
    
      finmar();//t
      delay(1000);
    digitalWrite(LED_D1, LOW); 
}