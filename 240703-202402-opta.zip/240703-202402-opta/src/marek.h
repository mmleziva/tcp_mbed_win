#include "mbed.h"
#include <BlockDevice.h>
#include <FATFileSystem.h>
#include <LittleFileSystem.h>
#include <MBRBlockDevice.h>
#include "EthernetInterface.h"

using namespace mbed;
void setmar(void);
void finmar(void);
 extern FILE* fp;
extern int p_Fmain[610];
extern int p_Amain[610];
extern int p_Fsuma[610];
extern int p_Esuma[610];
extern int p_DsumM[610];
extern int p_Cefe[610];